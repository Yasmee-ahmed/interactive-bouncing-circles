interface Circle {
  x: number;
  y: number;
  radius: number;
  color: string;
  vx: number;
  vy: number;
}

function start(): void {
  const canvas = document.getElementById("scene") as HTMLCanvasElement;
  const ctx = canvas.getContext("2d")!;
  const selectEl = document.getElementById("selected") as HTMLSelectElement;
  const colorInput = document.getElementById("color") as HTMLInputElement;
  const speedInput = document.getElementById("speed") as HTMLInputElement;
  const applyBtn = document.getElementById("apply") as HTMLButtonElement;
  const toggleBtn = document.getElementById("toggle") as HTMLButtonElement;
  const resetBtn = document.getElementById("reset") as HTMLButtonElement;
  const statusEl = document.getElementById("status") as HTMLElement;

  let circles: Circle[] = [
    { x: 100, y: 100, radius: 20, color: "blue", vx: 100, vy: 50 },
    { x: 250, y: 150, radius: 25, color: "red", vx: -80, vy: 70 },
    { x: 400, y: 200, radius: 15, color: "green", vx: 90, vy: -60 }
  ];
     //بشوف الداله شغاله ولا لا 
  let running: boolean = false;
//باخد الداله النشطه ف الدوائر
  const getIndex = (): number => Number(selectEl.value);

  const draw = (): void => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (const c of circles) {
      ctx.fillStyle = c.color;
      ctx.beginPath();
      ctx.arc(c.x, c.y, c.radius, 0, 2 * Math.PI);
      ctx.fill();
    }
    const active = circles[getIndex()];
    statusEl.textContent = `Circle ${getIndex() + 1} | X: ${active.x.toFixed(0)} Y: ${active.y.toFixed(0)}`;
  };

  selectEl.onchange = () => {
    const active = circles[getIndex()];
    colorInput.value = active.color;
    speedInput.value = Math.abs(active.vx).toString();
    draw();
  };

  colorInput.oninput = () => {
    circles[getIndex()].color = colorInput.value;
  };

  applyBtn.onclick = () => {
    const val = Number(speedInput.value);
    if (val >= 0) {
      const active = circles[getIndex()];
      const direction = active.vx < 0 ? -1 : 1;
      active.vx = val * direction;
    }
  };

  toggleBtn.onclick = () => {
    running = !running;
    toggleBtn.textContent = running ? "Pause" : "Resume";
  };

  resetBtn.onclick = () => {
    circles = [
      { x: 100, y: 100, radius: 20, color: "blue", vx: 100, vy: 50 },
      { x: 250, y: 150, radius: 25, color: "red", vx: -80, vy: 70 },
      { x: 400, y: 200, radius: 15, color: "green", vx: 90, vy: -60 }
    ];
    selectEl.value = "0";
    running = false;
    toggleBtn.textContent = "Resume";
    draw();
  };
// لما بضغط ب الماوس ف مكان معين بيحسب الاتجاهات وبيروح للمكان دا 
  canvas.onpointerdown = (e: PointerEvent) => {
    const rect = canvas.getBoundingClientRect();
    const active = circles[getIndex()];
    active.x = (e.clientX - rect.left) * (canvas.width / rect.width);
    active.y = (e.clientY - rect.top) * (canvas.height / rect.height);
  };

  let lastTime: number | undefined = undefined;
  const animate = (time: number) => {
    const dt = lastTime === undefined ? 0 : Math.min((time - lastTime) / 1000, 0.05);
    lastTime = time;

    if (running) {
      for (const c of circles) {
        c.x += c.vx * dt;
        if (c.x + c.radius > canvas.width || c.x - c.radius < 0) {
          c.vx *= -1;
        }

        c.y += c.vy * dt;
        if (c.y + c.radius > canvas.height || c.y - c.radius < 0) {
          c.vy *= -1;
        }
      }
    }

    draw();
    requestAnimationFrame(animate);
  };

  requestAnimationFrame(animate);
}

start();
export {};